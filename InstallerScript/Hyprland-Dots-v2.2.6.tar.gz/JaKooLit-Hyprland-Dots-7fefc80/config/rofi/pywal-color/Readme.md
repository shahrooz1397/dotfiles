# NOTE!!

This is symlink from ~/.cache/wal/colors-rofi-dark.rasi or ~/.cache/wal/colors-rofi-dark.rasi. Do not delete this folder and files else rofi theme wont be loaded.